<?php

namespace Drupal\generatepdf\Form;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\file\Entity\File;
use Mpdf\Mpdf;
use Mpdf\Output\Destination;

/*
 * custom registration form.
 */

class GeneratePDFForm extends FormBase {
  
  /**
   * The Mpdf object.
   *
   * @var \Mpdf\Mpdf
   */

  protected $mpdf;
  /*
   * { @inheritdoc }
   */
  
  public function getFormId() {
	  return 'generate_pdf_form';
  }
  
  /*
   * { @inheritdoc }
   */
  
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['submit'] = array(
      '#type' => 'submit',
      '#value' => 'Generated PDF',
    );
    return $form;
  }
  
  
  /*
   * { @inheritdoc }
   */
  
  public function validateForm(array &$form, FormStateInterface $form_state) {
	
  }
  
  /*
   * { @inheritdoc }
   */
	
  public function submitForm(array &$form, FormStateInterface $form_state) {
    try {
      $jsonobj = '[{
        "ID": "1234", 
        "Name": "Architecture",
        "Category": "Computers",
        "Price": "125.60"
      }]';
      $jsontext = json_decode($jsonobj, TRUE);
      $pdf_password = (int)$jsontext[0]['ID'];
      $html = 'Welcome to PDF';
      $mpdf = new \Mpdf\Mpdf(['mode' => 'utf-8', 'format' => [190, 236]]);
      $mpdf->SetProtection($permissions = [], $pdf_password, null, $length = 40);
      $mpdf->WriteHTML($html);  
      $folder = \Drupal::service('file_system')->realpath(file_default_scheme() . "://");
      $folder .= '/pdf_files';
      $mpdf->Output($folder . '/' . 'Passbook-'. $json_file_info[0]['Name'] . '.pdf', Destination::FILE);
    }
    catch (\Mpdf\MpdfException $e) { 
      // Note: safer fully qualified exception name used for catch
      // Process the exception, log, print etc.
      echo $e->getMessage();
    }	  
  }
  
  // we've writen this code where we need
  function __autoload($classname) {
    $filename = "./". $classname .".php";
    include_once($filename);
  }
}
