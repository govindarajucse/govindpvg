<?php 

// Include the main TCPDF library (search for installation path).
require_once('../TCPDF/tcpdf.php');
ob_start();
// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$json_info = '[
    {
        "ID": "1234", 
        "Name": "Architecture",
        "Category": "Computers",
        "Price": "125.60"
    }
]';

$jsontext = json_decode($json_info, true); 
$pdf_password = (int)$jsontext[0]['ID'];

$pdf->SetProtection(array('print', 'copy'), $pdf_password, null, 0, null);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Our Code World');
$pdf->SetTitle('Example Write Html');

// set default header data
$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, 'Passbook-'. $jsontext[0]['Name'], PDF_HEADER_STRING);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// add a page
$pdf->AddPage();

$html = '<h4>PDF Creation</h4><br><p>Welcome to Drupal</p>';
 
$pdf->writeHTML($html, true, false, true, false, '');
// add a page
$pdf->AddPage();

$html = '<h1>Hey</h1>';
// output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');

// reset pointer to the last page
$pdf->lastPage();
//Close and output PDF document

$pdf->Output('Passbook-' . $jsontext[0]['Name'] . '.pdf', 'I');
ob_end_flush(); 

?>